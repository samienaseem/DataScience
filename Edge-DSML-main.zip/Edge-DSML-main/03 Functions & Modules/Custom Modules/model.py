def greeter(name):
    return "Good morning " + name

def main():
    print("Whatever code")
    print("My name is:", __name__)


if __name__ == '__main__':
    print("This is confidential code.")
    main()